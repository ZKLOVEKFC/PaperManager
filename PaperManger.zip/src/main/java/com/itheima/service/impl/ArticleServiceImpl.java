package com.itheima.service.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.itheima.mapper.ArticleMapper;
import com.itheima.pojo.Article;
import com.itheima.pojo.PageBean;
import com.itheima.service.ArticleService;
import com.itheima.utils.ThreadLocalUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Service
public class ArticleServiceImpl implements ArticleService {

    @Autowired
    private ArticleMapper articleMapper;            //      注入一个mapper层的对象

    @Override
    public void add(Article article) {
        //补充属性值
        article.setCreateTime(LocalDateTime.now());     //获得创建、修改时间和创建人
        article.setUpdateTime(LocalDateTime.now());

        Map<String, Object> map = ThreadLocalUtil.get();      //        获得一个业务集合map
        Integer UserId = (Integer) map.get("id");                             //        从map中获得创建人ID

        article.setCreateUser(UserId);

        articleMapper.add(article);
    }

    @Override
    public PageBean<Article> list(Integer pageNum, Integer pageSize, Integer categoryId, String state) {
        //创建pageBean对象
        PageBean<Article> pageBean = new PageBean<>();

        //开启分页查询   PageHelper
        PageHelper.startPage(pageNum,pageSize);

        //调用mapper
        Map<String, Object> map = ThreadLocalUtil.get();      //获得用户id，只显示该id的文章
        Integer userId = (Integer) map.get("id");

        List <Article> as = articleMapper.list(userId,categoryId,state);

        //page提供的方法，获得pagehelper的分页信息（总记录条数和当前页数据）
        Page<Article> page = (Page<Article>) as;

        //填充数据到pageBean中
        pageBean.setTotal(page.getTotal());         //填充pageBean的总条数
        pageBean.setItems(page.getResult());        //填充pageBean的当前页数据集合
        return pageBean;
    }
}
